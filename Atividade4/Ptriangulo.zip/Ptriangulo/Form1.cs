﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double numeroA, numeroB, numeroC;
        string classificacao;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtA.Text, out numeroA)) || (numeroA == 0))
            {
                MessageBox.Show("Valor Inválido");
                txtA.Clear();
                txtA.Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtB.Text, out numeroB)) || (numeroB == 0))
            {
                MessageBox.Show("Valor Inválido");
                txtB.Clear();
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtC.Text, out numeroC)) || (numeroC == 0))
            {
                MessageBox.Show("Valor Inválido");
                txtC.Clear();
                txtC.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (((numeroA > Math.Abs(numeroB - numeroC)) && (numeroA < Math.Abs(numeroB + numeroC))) ||
               ((numeroA > Math.Abs(numeroB - numeroC)) && (numeroA < Math.Abs(numeroB + numeroC))) ||
               ((numeroA > Math.Abs(numeroB - numeroC)) && (numeroA < Math.Abs(numeroB + numeroC))))
                if ((numeroA == numeroB) && (numeroC == numeroB))
                {
                    classificacao = "Triângulo equilátero";
                    txtClassificacao.Text = classificacao;
                }
                else
                    if ((((numeroA == numeroB) && numeroA != numeroC)) || ((numeroA == numeroC) && ((numeroA != numeroB)))
                    || ((numeroB == numeroC) && (numeroB != numeroA)))
                     {
                        classificacao = "Triângulo isósceles";
                        txtClassificacao.Text = classificacao;
                     }
                    else
                    {
                        classificacao = "Triângulo escaleno";
                        txtClassificacao.Text = classificacao;
                    }
            else
            {
                MessageBox.Show("Não foi possível formar um triângulo");
                txtA.Focus();
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtClassificacao.Clear();

            txtA.Focus();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

    }
}
