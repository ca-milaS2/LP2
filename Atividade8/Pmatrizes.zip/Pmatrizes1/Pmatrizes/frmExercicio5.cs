﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] num = new string[2, 10];
            string[] respostas = { "A", "B", "C", "D", "E", "D", "C", "A", "E", "B" };
            string auxiliar = "";

            for (int i = 0; i < num.GetLength(0); i++)
                for (int j = 0; j < num.GetLength(1); j++)
                {

                    auxiliar = Interaction.InputBox($"Digite a {i + 1}° resposta da questão {j + 1}", "Entrada de Dados");

                    if (auxiliar is "A" || auxiliar is "B" || auxiliar is "C" || auxiliar is "D" || auxiliar is "E")
                        num[i, j] = auxiliar;
                    else
                    {
                        MessageBox.Show("Reposta inválida");
                        j--;
                    }
                }

            for (int i = 0; i < num.GetLength(0); i++)

                for (int j = 0; j < num.GetLength(1); j++)
                {
                    if (String.Compare(respostas[j], num[i,j], true) == 0)
                        lstbxRespostas.Items.Add($"o aluno {i + 1} acertou a questão: {j + 1} era {respostas[j]} escolheu {num[i, j]}");
                    else
                        lstbxRespostas.Items.Add($"o aluno {i + 1} errou a questão: {j + 1} era {respostas[j]} escolheu {num[i, j]}");
                }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxRespostas.Items.Clear();
        }
    }
}
