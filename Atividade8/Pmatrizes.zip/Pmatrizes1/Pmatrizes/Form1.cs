﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° número", "Entrada de Dados");

                if (auxiliar == "")
                {
                    break;
                }

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";

            foreach (int j in vetor)
            {
                auxiliar += j + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList(); //{"Ana", "André", ...}
            lista.Add("Ana");
            lista.Add("André");
            lista.Add("Beatriz");
            lista.Add("Camila");
            lista.Add("João");
            lista.Add("Joana");
            lista.Add("Otávio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            lista.Remove("Otávio");

            string resultado = string.Join("\n", lista.ToArray());
            MessageBox.Show(resultado);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[10, 3];
            double[] vetor = new double[10];
            string auxiliar = "";
            double num;

            for (int i = 0; i < matriz.GetLength(0); i++)
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox($"Digite as notas do {i + 1}° aluno", "Entrada de Dados");

                    if (Double.TryParse(auxiliar, out num))
                        if (num >= 0 && num <= 10)
                            matriz[i, j] = num;
                        else
                        {
                            MessageBox.Show("Nota inválida");
                            j--;
                        }
                }

            for (int i = 0; i < matriz.GetLength(0); i++)
                for (int j = 0; j < matriz.GetLength(1); j++)
                    vetor[i] += matriz[i, j];

            for (int i = 0; i < vetor.Length; i++)
                vetor[i] = vetor[i] / 3;

            for (int i = 0; i < vetor.Length; i++)
                MessageBox.Show($"Aluno {i + 1}: média: " + vetor[i].ToString("N2"));
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 Obj1 = new frmExercicio4();
            Obj1.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 Obj2 = new frmExercicio5();
            Obj2.Show();
        }
    }
}