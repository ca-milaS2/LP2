﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] nomes2 = new int[10];
            string auxiliar = "";

            for (int i = 0; i < nomes.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° nome", "Entrada de Dados");

                if (auxiliar == "")
                {
                    break;
                }

                nomes2[i] = auxiliar.Replace(" ", "").Length;
                lstbxNomes.Items.Add($"o nome {auxiliar} tem: {nomes2[i]} caracteres");

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxNomes.Items.Clear();
        }
    }
}
