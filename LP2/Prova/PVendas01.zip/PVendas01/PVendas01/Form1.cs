﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[3, 4];
            string auxiliar = "";
            double num, calculo = 0;
            double[] vetor = new double[3];
            int val = 1;

            for (int i = 0; i < matriz.GetLength(0); i++)
                for (int j = 0; j < matriz.GetLength(1); j++)
                {

                    auxiliar = Interaction.InputBox($"Digite as vendas do {i + 1} mês da semana {j + 1}°", "Entrada de Dados");

                    if (Double.TryParse(auxiliar, out num) && (num >= 0.00))
                    {
                            matriz[i, j] = num;
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido");
                        j--;
                    }
                }

            for (int i = 0; i < matriz.GetLength(0); i++)
            { 
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    vetor[i] += matriz[i, j];
                    calculo += matriz[i, j];
                }
            }

            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                    lstbxVendas.Items.Add($"Total do mês:  {i + 1}  Semana:  {j + 1}  {matriz[i, j]}" + "\n");

                lstbxVendas.Items.Add($">> Total do Mês:  {vetor[i].ToString("N2")}" + "\n");
                lstbxVendas.Items.Add($"-------------------" + "\n");
                val = 0;
            }

                lstbxVendas.Items.Add($">>Total Geral:  {calculo.ToString("N2")} " + "\n");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }
    }
}
